/*
=====================================================
; Title: Assignment 4.2
; Author: Professor Krasso
; Modified By: Tierre
; Date: April 11, 2021
; Description: calorie converter for assignment 4.2
=====================================================
*/

//FoodModel class per assignment requirements with id name and calories.
export class FoodModel {
    constructor(id, name, calories){
        this.id = id;
        this.name = name;
        this.calories = calories;
    }
}